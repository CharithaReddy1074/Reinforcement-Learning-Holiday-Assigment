import os
import pandas as pd
from tkinter import Tk
from tkinter.filedialog import askopenfilename
from game.board import Board
from game.game_logic import GameLogic
from model.train_model import train_model
from model.pac_algorithm import PACAlgorithm

def main():
    # Initialize the game board
    board = Board()
    game_logic = GameLogic(board)

    # Hide the root Tkinter window
    Tk().withdraw()

    # Prompt user for the path to the CSV file
    csv_path = askopenfilename(title="Select the board_states.csv file", filetypes=[("CSV files", "*.csv")])
    if not csv_path:
        print("No file selected.")
        return

    # Load training data
    training_data = pd.read_csv(csv_path)
    print("Columns in the CSV file:", training_data.columns)  # Debugging line
    model = train_model(training_data)

    # Game loop
    while not game_logic.is_game_over():
        board.display()
        start_pos, end_pos = game_logic.get_player_move()
        if game_logic.make_move(start_pos, end_pos):
            print(f"Move made from {start_pos} to {end_pos}")
        else:
            print("Invalid move. Try again.")

    print("Game over!")

if __name__ == "__main__":
    main()