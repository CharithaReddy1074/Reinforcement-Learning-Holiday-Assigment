def preprocess_board_state(board_state):
    # Convert the board state into a suitable format for the model
    return [piece for row in board_state for piece in row]

def evaluate_model_performance(predictions, actual_moves):
    # Calculate the accuracy of the model's predictions
    correct_predictions = sum(p == a for p, a in zip(predictions, actual_moves))
    return correct_predictions / len(actual_moves) if actual_moves else 0

def display_board(board):
    # Print the current state of the board in a readable format
    for row in board:
        print(" | ".join(row))
        print("-" * 15)