class Piece:
    def __init__(self, color):
        self.color = color

    def valid_moves(self, position, board):
        raise NotImplementedError("This method should be overridden by subclasses")


class King(Piece):
    def valid_moves(self, position, board):
        # Implement logic for valid King moves
        moves = []
        x, y = position
        for dx in [-1, 0, 1]:
            for dy in [-1, 0, 1]:
                if (dx != 0 or dy != 0) and 0 <= x + dx < 4 and 0 <= y + dy < 4:
                    moves.append((x + dx, y + dy))
        return moves


class Pawn(Piece):
    def valid_moves(self, position, board):
        # Implement logic for valid Pawn moves
        moves = []
        x, y = position
        if self.color == 'white':
            if x > 0:
                moves.append((x - 1, y))
        else:
            if x < 3:
                moves.append((x + 1, y))
        return moves