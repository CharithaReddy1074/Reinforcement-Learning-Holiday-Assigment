class Board:
    def __init__(self):
        # Initialize a 4x4 board with pieces
        self.board = [[0, 0, 0, 0],
                      [0, 1, 0, 0],
                      [0, 0, 0, 0],
                      [0, 0, 0, 2]]  # Example setup with 1 representing a pawn and 2 representing a king

    def get_piece(self, position):
        row, col = position
        return self.board[row][col]

    def move_piece(self, start_pos, end_pos):
        start_row, start_col = start_pos
        end_row, end_col = end_pos
        piece = self.board[start_row][start_col]
        self.board[start_row][start_col] = 0
        self.board[end_row][end_col] = piece

    def display(self):
        for row in self.board:
            print(' '.join(str(cell) for cell in row))
        print()