from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import numpy as np

class PACAlgorithm:
    def __init__(self):
        self.model = DecisionTreeClassifier()

    def train(self, board_states, optimal_moves):
        # Convert board states and optimal moves to a suitable format
        X = [self._board_state_to_features(state) for state in board_states]
        y = optimal_moves

        # Split the data into training and validation sets
        X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

        # Train the model
        self.model.fit(X_train, y_train)

        # Validate the model
        y_pred = self.model.predict(X_val)
        accuracy = accuracy_score(y_val, y_pred)
        print(f"Validation Accuracy: {accuracy * 100:.2f}%")

    def predict(self, board_state):
        # Convert the board state to features
        features = self._board_state_to_features(board_state)
        return self.model.predict([features])[0]

    def evaluate(self, test_data):
        # Extract board states and optimal moves from the test data
        board_states = test_data['state'].tolist()
        optimal_moves = test_data['move'].tolist()

        # Convert board states to features
        X_test = [self._board_state_to_features(state) for state in board_states]
        y_test = optimal_moves

        # Predict and evaluate
        y_pred = self.model.predict(X_test)
        accuracy = accuracy_score(y_test, y_pred)
        print(f"Test Accuracy: {accuracy * 100:.2f}%")

    def _board_state_to_features(self, board_state):
        # Convert the board state (a 2D list) to a flat list of features
        return np.array(eval(board_state)).flatten()