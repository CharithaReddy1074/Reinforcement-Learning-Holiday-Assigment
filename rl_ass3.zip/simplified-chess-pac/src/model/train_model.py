import pandas as pd
from model.pac_algorithm import PACAlgorithm

def train_model(training_data):
    # Ensure the columns 'state' and 'move' exist
    if 'state' not in training_data.columns or 'move' not in training_data.columns:
        raise KeyError("The CSV file must contain 'state' and 'move' columns.")

    # Extract board states and optimal moves from the training data
    board_states = training_data['state'].tolist()
    optimal_moves = training_data['move'].tolist()

    # Initialize and train the PAC algorithm model
    pac_model = PACAlgorithm()
    pac_model.train(board_states, optimal_moves)

    return pac_model