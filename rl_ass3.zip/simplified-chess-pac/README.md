# Simplified Chess PAC

This project implements a simplified chess-like game on a 4x4 board using the PAC (Probably Approximately Correct) algorithm. The game is designed to predict optimal moves based on supervised learning with a dataset of board states.

## Project Structure

```
simplified-chess-pac
├── src
│   ├── main.py               # Entry point of the application
│   ├── game
│   │   ├── board.py          # Defines the Board class
│   │   ├── pieces.py         # Defines game piece classes (e.g., King, Pawn)
│   │   └── game_logic.py     # Manages game rules and logic
│   ├── model
│   │   ├── pac_algorithm.py   # Implements the PAC learning algorithm
│   │   └── train_model.py     # Handles model training and evaluation
│   ├── data
│   │   └── board_states.csv   # Dataset of board states and optimal moves
│   └── utils
│       └── helpers.py        # Utility functions for data processing
├── requirements.txt          # Project dependencies
├── .gitignore                # Files to ignore in version control
└── README.md                 # Project documentation
```

## Setup Instructions

1. Clone the repository:
   ```
   git clone <repository-url>
   cd simplified-chess-pac
   ```

2. Install the required dependencies:
   ```
   pip install -r requirements.txt
   ```

3. Run the game:
   ```
   python src/main.py
   ```

## Usage

- The game allows two players to take turns making moves on a 4x4 board.
- The PAC algorithm predicts optimal moves based on the current board state.
- Players can choose from various pieces, each with its own movement rules.

## Overview

This project combines game development with machine learning techniques to create an engaging chess-like experience. The PAC algorithm is utilized to enhance gameplay by predicting the best possible moves based on historical data.