import numpy as np

class GameEnvironment:
    def __init__(self, n_actions):
        self.n_actions = n_actions
        self.reward_probabilities = np.random.rand(n_actions)

    def get_reward(self, action):
        return 1 if np.random.rand() < self.reward_probabilities[action] else 0