import numpy as np
import math
from game_environment import GameEnvironment

class UCBAlgorithm:
    def __init__(self, n_actions):
        self.n_actions = n_actions
        self.counts = np.zeros(n_actions)
        self.values = np.zeros(n_actions)

    def select_action(self):
        total_counts = np.sum(self.counts)
        if total_counts < self.n_actions:
            return int(total_counts)
        ucb_values = self.values + np.sqrt(2 * np.log(total_counts) / (self.counts + 1e-5))
        return int(np.argmax(ucb_values))

    def update(self, action, reward):
        self.counts[action] += 1
        n = self.counts[action]
        value = self.values[action]
        self.values[action] = ((n - 1) / n) * value + (1 / n) * reward

def simulate_game(n_actions, n_rounds):
    env = GameEnvironment(n_actions)
    ucb = UCBAlgorithm(n_actions)
    total_reward = 0

    for _ in range(n_rounds):
        action = ucb.select_action()
        reward = env.get_reward(action)
        ucb.update(action, reward)
        total_reward += reward

    return total_reward

if __name__ == "__main__":
    n_actions = 10
    n_rounds = 1000
    total_reward = simulate_game(n_actions, n_rounds)
    print(f"Total reward after {n_rounds} rounds: {total_reward}")