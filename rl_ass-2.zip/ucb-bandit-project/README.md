# UCB Bandit Project

This project implements the Upper Confidence Bound (UCB) algorithm to solve the multi-armed bandit problem. The goal is to optimize player rewards in a basic game simulation where a player chooses between different actions with hidden reward probabilities.

## Overview

The UCB algorithm is a popular approach in reinforcement learning that balances exploration and exploitation. It selects actions based on their estimated values while considering the uncertainty in those estimates. This project simulates a game environment where a player can choose from multiple actions, each with its own reward probability.

## Project Structure

```
ucb-bandit-project
├── src
│   ├── game_environment.py  # Contains the GameEnvironment class for simulating the game.
│   ├── simulation.py        # Contains the simulate_game function to run the game simulation.
│   └── __init__.py          # Marks the src directory as a Python package.
├── requirements.txt          # Lists the project dependencies.
└── README.md                 # Documentation for the project.
```

## Installation

To run this project, you need to have Python installed along with the required dependencies. You can install the dependencies using pip:

```
pip install -r requirements.txt
```

## Running the Simulation

To run the game simulation, execute the `simulation.py` file. You can customize the number of actions and rounds by modifying the parameters in the `simulate_game` function.

```python
from src.simulation import simulate_game

simulate_game(n_actions=5, n_rounds=1000)
```

## License

This project is open-source and available under the MIT License.